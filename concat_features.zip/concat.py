import os
import sys
import json
import struct
import numpy as np
from sklearn.decomposition import IncrementalPCA
from sklearn.externals import joblib
from sklearn import preprocessing
import matio
import argparse

def parse_args(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('--aDir', type=str, default='test/t1', help='feature dir a')
    parser.add_argument('--bDir', type=str, default='test/t2', help='feature dir b')
    parser.add_argument('--saveDir', type=str, default='testout', help='save dir')
    return parser.parse_args(argv)

def write_bin(path, feature):
    feature = list(feature)
    #print(len(feature))
    with open(path, 'wb') as f:
        f.write(struct.pack('4i', len(feature),1,4,5))
        f.write(struct.pack("%df"%len(feature), *feature))

def createPath_write_bin(path, feature):
    try:
        file_dir = os.path.split(path)[0]
        if not os.path.isdir(file_dir):
            os.makedirs(file_dir)
    except:
        pass 
    write_bin(path, feature)
    return

def recursive_list(targetDir, outList=[]):
    for path in os.listdir(targetDir):
        if path.startswith('.'):
            continue
        fullPath = os.path.join(targetDir, path)
        if os.path.isdir(fullPath):
            recursive_list(fullPath, outList)
        else:
            outList.append(fullPath)
    return outList
        
def concat_from_list(aDir, bDir, pathList, saveDir):
    for path in pathList:
        aPath = path
        bPath = path.replace(aDir, bDir)
        _concatedPath = path.replace(aDir, '')
        concatedPath = os.path.join(saveDir, _concatedPath)
        try:
            aFeatureVec = np.transpose(matio.load_mat(aPath))
            bFeatureVec = np.transpose(matio.load_mat(bPath))
            concatedFeatureVec = np.concatenate((aFeatureVec, bFeatureVec), axis=1)
            #print concatedPath
            createPath_write_bin(concatedPath, concatedFeatureVec)
        except:
            print 'unable to process'
    return 




def main(args):
    print('===> args:\n', args)
    
    aDir = args.aDir
    bDir = args.bDir
    prefix = aDir.split('/')[-1]
    suffix = bDir.split('/')[-1]
    if prefix == '':
        prefix = aDir.split('/')[-2]
    if suffix == '':
        suffix = bDir.split('/')[-2]
    saveDir = os.path.join(args.saveDir, 'concat_' + prefix + suffix)

    if not os.path.exists(saveDir):
        os.makedirs(saveDir)
    
    featurePathList = recursive_list(aDir)
    print 'fea'
    concat_from_list(aDir, bDir, featurePathList, saveDir)
    print 'haah'

    
if __name__ == '__main__':
    main(parse_args(sys.argv[1:]))
