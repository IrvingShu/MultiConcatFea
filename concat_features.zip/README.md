# work12

使用说明：
aDir：第一个feature文件夹
bDir：第二个feature文件夹
saveDir：输出文件夹

运行方式：
递归遍历aDir中的所有feature文件，所以aDir和bDir下的feature存放路径没有要求，但aDir和bDir下的存放路径要完全一致，会跳过不一致的feature文件，输出存放路径和aDir一致。